function PageNotFound() {
  return (
    <>
      <h1>404</h1>
      <p>Все сломалось...</p>
    </>
  );
}

export default PageNotFound;
