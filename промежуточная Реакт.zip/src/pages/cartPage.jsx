import Cart from "../components/cart/cart";

function CartPage() {
  return <Cart />;
}

export default CartPage;
