import { Link } from "react-router-dom";
import "./cart.css";
import { useDispatch, useSelector } from "react-redux";
import Item from "../card-item/item";

function Cart() {
  const products = useSelector((state) => {
    return state.cart.positions;
  });

  const dispatch = useDispatch();
  const handleClick = (index, price) => {
    dispatch({
      type: "DELETE_TO_CART",
      payload: { price: price, index: index },
    });
  };

  const cartSumm = useSelector((state) => state.cart.price);
  return (
    <div className="cart">
      <div className="cart-header">
        <Link className="cart-header__link" to="/">
          <img
            alt=""
            className="cart-header__button"
            srcSet="./images/ui/button_back.svg"
          />
        </Link>
        <h1>Корзина с выбранными товарами</h1>
      </div>
      <div className="cart-cards">
        {products.map((item, index) => {
          return (
            <div className="cart-cards__item" key={index}>
              <Item
                image={"./images/cards/" + item.image}
                name={item.title}
                price={item.price}
                buttonImage="./images/ui/button_remove.svg"
                clickFunction={(e) => {
                  handleClick(index, item.price);
                }}
              />
            </div>
          );
        })}
      </div>
      <div className="cart-footer">
        <p className="cart-footer__text">
          Заказ на сумму:{" "}
          <span className="cart-footer__text-summ">{cartSumm} ₽</span>
        </p>
        <button className="cart-footer__button">Оформить заказ</button>
      </div>
    </div>
  );
}

export default Cart;
